#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 28 20:05:09 2020

@author: Rodrigo
"""
#la solucion inicia en la linea 165
import numpy as np
import pandas as pd
from math import acos, cos, sin, radians

def check_optimality(gk,Hk,tolT): 
#   Revisa que se cumplan las condiciones de optimalidad: Grad=0, Hess positiva semidefinida

#   gk - Vector Gradiente de f en xk
#   Hk - Matriz Hessiana de f en xk
#   tolT - Tolerancia de el gradiente

    return es_pos_def(Hk) and all(abs(gk)<tolT)

def Grad(f, xk, h):
#   Calcula el gradiende de f en xk, con diferencia h

#   f - Función
#   xk - Punto a evaluar
#   h - Diferencia de aproximación

    n = xk.size
    g = np.zeros(n)
    for i in range(0, n):
        b = np.copy(xk)
        b[i] += h
        g[i] = (f(b) - f(xk))/(h)
    return g

def Hess(f,xk,h):
#   Calcula el Hessiano en xk, con diferencia h

#   f - Función
#   xk - Punto a evaluar
#   h - Diferencia de aproximación

    n=xk.size
    H=np.zeros((n,n))
    for i in range(0,n):
        for j in range(0,n):
            ff=np.copy(xk)
            ff[i]+=h
            ff[j]+=h
            
            fb=np.copy(xk)
            fb[i]+=h
            fb[j]-=h
            
            bf=np.copy(xk)
            bf[i]-=h
            bf[j]+=h
            
            bb=np.copy(xk)
            bb[i]-=h
            bb[j]-=h
            
            H[i,j]=(f(ff)-f(fb)-f(bf)+f(bb))/(4*h**2)
    return H

def es_pos_def(A):
#   Prueba si la matriz A es positiva semidefinida si A es simétrica

#   A - Matriz a probar

        try:
            np.linalg.cholesky(A)
            return True
        except np.linalg.LinAlgError:
            return False
        return False

def PruebaMod_Hess(Hk, Beta ) :
#   Modifica la Hessiana para que sea positiva semidefinida, según el algoritmo 3.3 de Nocedal Ed. 2

#   Hk - Matrizz hessiana a modificar
#   Beta - Valor arbitrario a aumentar

    n=int(np.sqrt(np.size(Hk)))
    tk=0
    v=np.matrix.diagonal(Hk)
    
    if min(v)<0:
        tk=-min(v)+Beta    
    

    while es_pos_def(Hk+np.eye(n)*tk)==False:
           tk= max(2*tk, Beta);
    
    return Hk+np.eye(n)*tk


def BactrackSearch(f,xk,pk,gk,alpha0,c,rho):
#   Busca el paso según el algoritmo de 3.1 de Nocedal Ed. 2

#   f - Función a evaluar
#   xk - punto alrededor del que se evalúa
#   pk -Dirección elegida previamente
#   alpha0 - Valor de paso máximo
#   c - peso sobre la derivada direccional
#   rho - factor de disminución del paso

    alpha_k=alpha0
   

    while f(xk+alpha_k*pk)> f(xk)+c*alpha_k*np.dot(gk,pk):
        
        alpha_k=alpha_k*rho
    return alpha_k


def Min_LineSearchNewton(f , x0 , tolT , h1 ,h2 , alpha0, c, rho,maxit):  
#   Busca el mínimo de una función dada una aproximación inicial x0. Utiliza el método de búsqueda lineal de Newton
#   con una aproximación de la Hessiana adaptada

#   f-Función
#   x0 - Punto inicial
#   tolT -  Tolerancia sobre condición de optimalidad
#   h1 -Diferencias para gradiente
#   h2 -Diferencias para Hessiana
#   c - peso sobre el gradiente para búsqueda lineal Bactracking
#   rho - factor de disminución del paso para búsqueda lineal Bactracking
#   maxit - Máximo número de Iteraciones

    xk=x0
    n=np.size(x0)
    for k in range(0,maxit):
    
    
        gk=Grad(f,xk,h1)                                       
        Hk=Hess(f,xk,h2)         
        
        if check_optimality(gk,Hk,tolT) :
            break
        
        HessMod=PruebaMod_Hess( Hk, 1e-3 ) 

        pk= -np.linalg.solve(HessMod,gk)
        
        
        alpha_k=BactrackSearch(f,xk, pk, gk, alpha0 ,c,  rho) 
        
        xk_1=xk
        xk=xk+alpha_k*pk
        
        
        print(xk)
        print(f(xk))
            
    return [xk,k]








#----------------------------------------------
#la idea será minimizar la distancia de los crímenes a las camaras
#costo1 es la suma de las distancias de los crimenes a las camaras, el problema es que se podría centrar en un solo punto
#para evitar eso se suma un termino que hace que entre mas cerca esten las camaras entre si mas grande es la funcion de costo
    

data = pd.read_csv('crime_data.csv',sep = ',',header = None)
data = data.to_numpy()
lat = data[:,3]
long = data[:,4]
#lat es el vector de latitudes de los crimenes, long el vector de longitudes de los crimenes
#X1 es el vector de latitudes de las camaras y X2 el vector de longitudes de las camaras
def costo(lat, long, X1, X2):
    costo1 = 0
    costo2 = 0
    for i in range (0,8000):
        for j in range (0,np.size(lat)):
            costo1 = costo1 + ((X1[i]-lat[j])**2 +(X2[i]-lat[j])**2)**1/2
            
            
    for i in range (0,8000):
        for j in range (0,np.size(lat)):
            costo2 = costo2 + ((X1[i]-lat[j])**2 +(X2[i]-lat[j])**2)**-1/2
    return costo1 + costo2

#aplicar el linesearch a la funcion costo para encontrar las latitudes y longitudes optimas
    
            
    













